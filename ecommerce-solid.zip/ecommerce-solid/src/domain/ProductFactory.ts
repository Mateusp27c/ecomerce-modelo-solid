import { Product } from './IProduct';
import { PhysicalProduct } from './PhysicalProduct';
import { DigitalProduct } from './DigitalProduct';
import { ProductData } from '../repositories/IProductRepository';

export class ProductFactory {
  static createProduct(data: ProductData): Product {
    if (data.type === 'physical') {
      return new PhysicalProduct(data.id, data.name, data.price);
    }
    if (data.type === 'digital') {
      return new DigitalProduct(data.id, data.name, data.price);
    }
    throw new Error(`Unknown product type: ${data.type}`);
  }
}
