export interface Product {
  readonly id: number;
  readonly name: string;
  readonly type: string;
  readonly price: number;
  calculateFreight(): number;
}
