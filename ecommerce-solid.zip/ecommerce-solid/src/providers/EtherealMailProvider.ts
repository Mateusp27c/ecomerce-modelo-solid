import nodemailer from 'nodemailer';
import { getMailClient } from '../lib/mail';
import { IMailProvider, MailMessage, MailResult } from './IMailProvider';

export class EtherealMailProvider implements IMailProvider {
  async sendMail(message: MailMessage): Promise<MailResult> {
    const mailer = await getMailClient();
    const info = await mailer.sendMail(message);
    return { previewUrl: nodemailer.getTestMessageUrl(info) };
  }
}
