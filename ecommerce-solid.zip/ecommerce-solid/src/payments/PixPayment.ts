import { IPaymentMethod } from './IPaymentMethod';
import logger from '../lib/logger';

export class PixPayment implements IPaymentMethod {
  async process(_paymentDetails: any): Promise<void> {
    logger.info('Processando Pix...');
  }
}
