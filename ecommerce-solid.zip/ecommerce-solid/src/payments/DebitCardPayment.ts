import { IPaymentMethod } from './IPaymentMethod';
import logger from '../lib/logger';

export class DebitCardPayment implements IPaymentMethod {
  async process(_paymentDetails: any): Promise<void> {
    logger.info('Processando débito...');
  }
}
