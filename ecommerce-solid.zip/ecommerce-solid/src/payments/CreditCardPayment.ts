import { IPaymentMethod } from './IPaymentMethod';
import { AppError } from '../errors/AppError';
import logger from '../lib/logger';

export class CreditCardPayment implements IPaymentMethod {
  async process(paymentDetails: any): Promise<void> {
    if (!paymentDetails?.cardNumber || !paymentDetails?.cvv) {
      throw new AppError('Dados do cartão incompletos', 400);
    }
    logger.info(`Processando cartão final ${String(paymentDetails.cardNumber).slice(-4)}`);
    if (paymentDetails.cvv === '000') {
      throw new AppError('Cartão recusado', 402);
    }
  }
}
