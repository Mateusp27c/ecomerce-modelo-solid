import { PrismaClient } from '@prisma/client';
import { IOrderRepository, CreateOrderData, OrderRecord } from './IOrderRepository';

export class PrismaOrderRepository implements IOrderRepository {
  constructor(private readonly prisma: PrismaClient) {}

  async create(data: CreateOrderData): Promise<OrderRecord> {
    return this.prisma.order.create({ data });
  }
}
