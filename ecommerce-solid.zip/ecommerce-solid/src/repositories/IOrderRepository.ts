export interface CreateOrderData {
  customer: string;
  items: string;
  total: number;
  status: string;
}

export interface OrderRecord {
  id: number;
}

export interface IOrderRepository {
  create(data: CreateOrderData): Promise<OrderRecord>;
}
