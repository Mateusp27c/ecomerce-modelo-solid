export interface ProductData {
  id: number;
  name: string;
  type: string;
  price: number;
}

export interface IProductRepository {
  findById(id: number): Promise<ProductData | null>;
}
