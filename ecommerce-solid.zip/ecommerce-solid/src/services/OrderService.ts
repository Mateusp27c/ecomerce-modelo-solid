import { ProductFactory } from '../domain/ProductFactory';
import { Product } from '../domain/IProduct';
import { IPaymentMethod } from '../payments/IPaymentMethod';
import { IOrderRepository } from '../repositories/IOrderRepository';
import { IProductRepository } from '../repositories/IProductRepository';
import { NotificationService } from './NotificationService';
import { AppError } from '../errors/AppError';
import logger from '../lib/logger';

export interface OrderItemInput {
  productId: number;
  quantity: number;
}

export interface ProcessOrderInput {
  customer: string;
  items: OrderItemInput[];
  paymentMethod: string;
  paymentDetails: any;
}

export interface ProcessOrderResult {
  orderId: number;
  emailPreview: string | false;
}

interface OrderLine {
  product: Product;
  quantity: number;
}

export class OrderService {
  constructor(
    private readonly productRepository: IProductRepository,
    private readonly orderRepository: IOrderRepository,
    private readonly paymentMethods: Record<string, IPaymentMethod>,
    private readonly notificationService: NotificationService
  ) {}

  async processOrder(input: ProcessOrderInput): Promise<ProcessOrderResult> {
    const { customer, items, paymentMethod, paymentDetails } = input;

    this.validate(customer, items, paymentMethod);

    const lines = await this.loadOrderLines(items);
    const totalAmount = this.calculateTotal(lines);

    await this.pay(paymentMethod, paymentDetails);

    const order = await this.orderRepository.create({
      customer,
      items: JSON.stringify(
        lines.map(({ product, quantity }) => ({
          id: product.id,
          name: product.name,
          type: product.type,
          price: product.price,
          quantity,
        }))
      ),
      total: totalAmount,
      status: 'confirmed',
    });

    const emailPreview = await this.notificationService.sendOrderConfirmation(
      customer,
      order.id,
      totalAmount,
      lines.map(({ product }) => ({ name: product.name }))
    );

    return { orderId: order.id, emailPreview };
  }

  private validate(
    customer: string | undefined,
    items: OrderItemInput[] | undefined,
    paymentMethod: string | undefined
  ): void {
    if (!customer || typeof customer !== 'string') {
      throw new AppError('Cliente inválido', 400);
    }

    if (!items || !Array.isArray(items) || items.length === 0) {
      logger.error('Tentativa de pedido sem itens');
      throw new AppError('Carrinho vazio', 400);
    }

    for (const item of items) {
      if (
        typeof item?.productId !== 'number' ||
        typeof item?.quantity !== 'number' ||
        !Number.isInteger(item.quantity) ||
        item.quantity <= 0
      ) {
        throw new AppError('Item inválido (productId/quantity)', 400);
      }
    }

    if (!paymentMethod || typeof paymentMethod !== 'string') {
      throw new AppError('Método de pagamento não informado', 400);
    }
  }

  private async loadOrderLines(items: OrderItemInput[]): Promise<OrderLine[]> {
    const lines: OrderLine[] = [];

    for (const item of items) {
      const data = await this.productRepository.findById(item.productId);

      if (!data) {
        throw new AppError(`Produto ${item.productId} não encontrado`, 400);
      }

      lines.push({ product: ProductFactory.createProduct(data), quantity: item.quantity });
    }

    return lines;
  }

  private calculateTotal(lines: OrderLine[]): number {
    return lines.reduce(
      (total, { product, quantity }) =>
        total + product.price * quantity + product.calculateFreight(),
      0
    );
  }

  private async pay(paymentMethod: string, paymentDetails: any): Promise<void> {
    const method = this.paymentMethods[paymentMethod];

    if (!method) {
      throw new AppError('Método de pagamento não suportado', 400);
    }

    await method.process(paymentDetails);
  }
}
