# E-commerce (refatorado com SOLID)

## Como executar

```bash
npm install
npm run setup     # prisma generate + cria o banco SQLite + seed de produtos
npm run dev       # sobe em http://localhost:3000
```

Para produção: `npm run build && npm start`.

## Testando

Produtos do seed: `1` (físico, 250), `2` (físico, 120), `3` (digital, 49.9).

```bash
curl -X POST http://localhost:3000/orders \
  -H "Content-Type: application/json" \
  -d '{
    "customer": "cliente@email.com",
    "items": [{ "productId": 1, "quantity": 2 }, { "productId": 3, "quantity": 1 }],
    "paymentMethod": "credit_card",
    "paymentDetails": { "cardNumber": "4111111111111111", "cvv": "123" }
  }'
```

Métodos de pagamento: `credit_card`, `debit_card`, `pix`.
A resposta traz `emailPreview`, um link do Ethereal com o e-mail enviado (precisa de internet).

Casos de erro: carrinho vazio (400), produto inexistente (400), cartão com cvv `000` (402), método inválido (400).
