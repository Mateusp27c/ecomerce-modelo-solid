import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  await prisma.product.deleteMany();
  await prisma.product.createMany({
    data: [
      { id: 1, name: 'Teclado Mecânico', type: 'physical', price: 250 },
      { id: 2, name: 'Mouse Gamer', type: 'physical', price: 120 },
      { id: 3, name: 'E-book TypeScript', type: 'digital', price: 49.9 },
    ],
  });
  console.log('Seed concluído: 3 produtos criados.');
}

main().finally(() => prisma.$disconnect());
